package com.example.practicle_work_9

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
